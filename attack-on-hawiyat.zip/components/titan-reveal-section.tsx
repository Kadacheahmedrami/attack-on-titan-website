"use client"

import { useRef, useEffect, useState } from "react"
import {
  motion,
  useScroll,
  useTransform,
  useSpring,
  useMotionTemplate,
  useInView,
  AnimatePresence,
} from "framer-motion"
import Image from "next/image"
import GlitchText from "./glitch-text"

const TitanRevealSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null)
  const imageRef = useRef<HTMLDivElement>(null)
  const textRef = useRef<HTMLDivElement>(null)
  const isInView = useInView(sectionRef, { once: false, margin: "-100px 0px" })

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  })

  // Parallax and opacity effects
  const y = useTransform(scrollYProgress, [0, 1], [100, -100])
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [1.1, 1, 0.9])
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0])
  const textY = useTransform(scrollYProgress, [0, 0.5, 1], [100, 0, -50])
  const textOpacity = useTransform(scrollYProgress, [0.1, 0.2, 0.8, 0.9], [0, 1, 1, 0])

  // Lighting and filter effects
  const brightness = useTransform(scrollYProgress, [0, 0.3, 0.6, 1], [0.3, 0.6, 0.8, 0.4])
  const contrast = useTransform(scrollYProgress, [0, 0.5, 1], [1.1, 1.3, 1.1])
  const blur = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [5, 0, 0, 5])

  // Smooth spring animations
  const springY = useSpring(y, { stiffness: 100, damping: 30 })
  const springScale = useSpring(scale, { stiffness: 100, damping: 30 })
  const springTextY = useSpring(textY, { stiffness: 100, damping: 30 })

  // Combined filter effect
  const filter = useMotionTemplate`brightness(${brightness}) contrast(${contrast}) blur(${blur}px)`

  // Mask reveal effect
  const maskSize = useTransform(scrollYProgress, [0, 0.3], ["0%", "100%"])
  const springMaskSize = useSpring(maskSize, { stiffness: 60, damping: 20 })

  // Text animation sequence
  const [textVisible, setTextVisible] = useState(false)

  // Particle effect
  const [particles, setParticles] = useState<
    Array<{
      x: number
      y: number
      size: number
      speed: number
      opacity: number
      direction: number
    }>
  >([])

  // Create particles
  useEffect(() => {
    if (!sectionRef.current) return

    const newParticles = []
    for (let i = 0; i < 50; i++) {
      newParticles.push({
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: Math.random() * 3 + 1,
        speed: Math.random() * 0.5 + 0.1,
        opacity: Math.random() * 0.5 + 0.2,
        direction: Math.random() > 0.5 ? 1 : -1,
      })
    }

    setParticles(newParticles)
  }, [])

  // Handle text visibility
  useEffect(() => {
    if (isInView) {
      const timer = setTimeout(() => {
        setTextVisible(true)
      }, 500)
      return () => clearTimeout(timer)
    }
    return undefined
  }, [isInView])

  // Light ray positions
  const lightRayPositions = [10, 30, 50, 70, 90]

  return (
    <section ref={sectionRef} className="relative h-[200vh] overflow-hidden bg-black">
      <div className="sticky top-0 h-screen w-full overflow-hidden">
        {/* Background gradient */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-b from-black via-gray-900 to-red-950/30"
          style={{ opacity: useTransform(scrollYProgress, [0, 0.5, 1], [1, 0.7, 0.5]) }}
        />

        {/* Particles */}
        {particles.map((particle, index) => (
          <motion.div
            key={index}
            className="absolute rounded-full bg-red-500"
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              width: particle.size,
              height: particle.size,
              opacity: particle.opacity,
            }}
            animate={{
              x: [0, particle.speed * 100 * particle.direction, 0],
              y: [0, particle.speed * 100 * particle.direction * -1, 0],
            }}
            transition={{
              duration: 10 + Math.random() * 20,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
          />
        ))}

        {/* Main image with effects */}
        <motion.div
          ref={imageRef}
          className="relative h-full w-full"
          style={{
            y: springY,
            scale: springScale,
            opacity,
          }}
        >
          {/* Image mask reveal effect */}
          <motion.div
            className="absolute inset-0 overflow-hidden"
            style={{
              clipPath: useMotionTemplate`circle(${springMaskSize} at center)`,
            }}
          >
            <motion.div className="absolute inset-0 flex items-center justify-center" style={{ filter }}>
              <div className="relative h-full w-full">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Reiner-looks-up-at-Eren-destroying-Marley.jpg-RILi0YAGZ2CY0gPGhQq7Swp9LpWm1m.jpeg"
                  alt="Eren in titan form destroying Marley with Reiner looking up"
                  fill
                  className="object-cover object-center"
                  priority
                />

                {/* Overlay effects */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"
                  style={{ opacity: useTransform(scrollYProgress, [0, 0.5, 1], [0.7, 0.4, 0.6]) }}
                />

                <motion.div
                  className="absolute inset-0 bg-red-900/20 mix-blend-overlay"
                  style={{ opacity: useTransform(scrollYProgress, [0, 0.5, 1], [0, 0.3, 0]) }}
                />
              </div>
            </motion.div>
          </motion.div>

          {/* Light rays effect */}
          <div className="absolute inset-0 overflow-hidden opacity-30 mix-blend-screen">
            {lightRayPositions.map((position, i) => (
              <motion.div
                key={i}
                className="absolute top-0 h-full w-[30px] bg-gradient-to-b from-red-500/0 via-red-500/30 to-red-500/0"
                style={{
                  left: `${position}%`,
                  rotate: i % 2 === 0 ? 15 : -15,
                }}
                animate={{
                  opacity: [0, 0.7, 0],
                  scale: [0.8, 1.2, 0.8],
                }}
                transition={{
                  duration: 8,
                  times: [0, 0.5, 1],
                  repeat: Number.POSITIVE_INFINITY,
                  delay: i * 0.5,
                }}
              />
            ))}
          </div>

          {/* Text content */}
          <motion.div
            ref={textRef}
            className="absolute inset-0 flex flex-col items-center justify-center px-4 text-center"
            style={{
              y: springTextY,
              opacity: textOpacity,
            }}
          >
            <AnimatePresence>
              {textVisible && (
                <>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.2 }}
                    className="mb-4"
                  >
                    <GlitchText
                      text="THE RUMBLING BEGINS"
                      className="text-4xl md:text-6xl font-bold text-white mb-2"
                      intensity={2}
                    />
                  </motion.div>

                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.8, delay: 0.6 }}
                    className="max-w-2xl text-xl md:text-2xl text-gray-200 mb-8"
                  >
                    Just as Eren unleashed devastation upon Marley, our Hawiyat platform will crush all who dare to
                    challenge it.
                  </motion.p>

                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{
                      duration: 0.5,
                      delay: 1,
                      type: "spring",
                      stiffness: 200,
                    }}
                    className="relative"
                  >
                    <div className="relative z-10 bg-gradient-to-r from-red-800 to-red-950 px-8 py-4 text-white font-bold tracking-wider border border-red-700/30 shadow-lg shadow-red-900/50">
                      WITNESS THE POWER
                    </div>
                    <motion.div
                      className="absolute inset-0 bg-red-600/30"
                      animate={{
                        boxShadow: [
                          "0 0 0px 0px rgba(255,0,0,0)",
                          "0 0 20px 10px rgba(255,0,0,0.4)",
                          "0 0 0px 0px rgba(255,0,0,0)",
                        ],
                      }}
                      transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                    />
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-10 left-0 right-0 flex justify-center"
          style={{
            opacity: useTransform(scrollYProgress, [0, 0.2], [1, 0]),
          }}
        >
          <motion.div
            animate={{
              y: [0, 10, 0],
            }}
            transition={{
              duration: 2,
              ease: "easeInOut",
              repeat: Number.POSITIVE_INFINITY,
            }}
            className="flex flex-col items-center"
          >
            <p className="text-gray-400 mb-2 text-sm">SCROLL TO WITNESS</p>
            <div className="w-6 h-10 rounded-full border-2 border-gray-400 flex justify-center p-1">
              <motion.div
                animate={{
                  y: [0, 12, 0],
                }}
                transition={{
                  duration: 1.5,
                  ease: "easeInOut",
                  repeat: Number.POSITIVE_INFINITY,
                }}
                className="w-2 h-2 bg-red-500 rounded-full"
              />
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

export default TitanRevealSection
