"use client"

import { useRef, useEffect, useState } from "react"
import { motion, useScroll, useTransform, useSpring, AnimatePresence } from "framer-motion"
import Image from "next/image"
import GlitchText from "./glitch-text"

const TitanRevealSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [textVisible, setTextVisible] = useState(false)

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  })

  // Simplified effects
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0])
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [1.1, 1, 0.95])
  const brightness = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0.3, 0.7, 0.7, 0.3])
  const textY = useTransform(scrollYProgress, [0.2, 0.5, 0.8], [50, 0, -50])

  // Spring animations for smoother motion
  const springScale = useSpring(scale, { stiffness: 100, damping: 30 })
  const springTextY = useSpring(textY, { stiffness: 100, damping: 30 })

  useEffect(() => {
    const handleScroll = () => {
      if (scrollYProgress.get() > 0.2 && !textVisible) {
        setTextVisible(true)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [scrollYProgress, textVisible])

  return (
    <section ref={sectionRef} className="relative h-[150vh] overflow-hidden bg-black">
      <div className="sticky top-0 h-screen w-full overflow-hidden">
        {/* Background gradient */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-b from-black via-gray-900 to-red-950/30"
          style={{ opacity: useTransform(scrollYProgress, [0, 0.5, 1], [1, 0.7, 0.5]) }}
        />

        {/* Main image with effects */}
        <motion.div
          className="relative h-full w-full"
          style={{
            scale: springScale,
            opacity,
          }}
        >
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.div
              className="relative w-full h-full"
              style={{
                filter: `brightness(${brightness})`,
              }}
            >
              <Image
                src="/rumbling.png"
                alt="The Rumbling - Eren's Titan Army"
                fill
                className="object-cover object-center"
                priority
              />

              {/* Overlay effects */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"
                style={{ opacity: useTransform(scrollYProgress, [0, 0.5, 1], [0.7, 0.4, 0.6]) }}
              />

              <motion.div
                className="absolute inset-0 bg-red-900/20 mix-blend-overlay"
                style={{ opacity: useTransform(scrollYProgress, [0, 0.5, 1], [0, 0.3, 0]) }}
              />
            </motion.div>
          </div>

          {/* Text content */}
          <motion.div
            className="absolute inset-0 flex flex-col items-center justify-center px-4 text-center"
            style={{
              y: springTextY,
              opacity: useTransform(scrollYProgress, [0.1, 0.2, 0.8, 0.9], [0, 1, 1, 0]),
            }}
          >
            <AnimatePresence>
              {textVisible && (
                <>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                    className="mb-4"
                  >
                    <GlitchText
                      text="THE RUMBLING BEGINS"
                      className="text-4xl md:text-7xl font-bold text-white mb-2"
                      intensity={2}
                    />
                  </motion.div>

                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.8, delay: 0.3 }}
                    className="max-w-2xl text-xl md:text-2xl text-gray-200 mb-8"
                  >
                    Just as Eren unleashed devastation upon Marley, our Hawiyat platform will crush all who dare to
                    challenge it.
                  </motion.p>

                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{
                      duration: 0.5,
                      delay: 0.6,
                      type: "spring",
                      stiffness: 200,
                    }}
                    className="relative"
                  >
                    <div className="relative z-10 bg-gradient-to-r from-red-800 to-red-950 px-8 py-4 text-white font-bold tracking-wider border border-red-700/30 shadow-lg shadow-red-900/50">
                      WITNESS THE POWER
                    </div>
                    <motion.div
                      className="absolute inset-0 bg-red-600/30"
                      animate={{
                        boxShadow: [
                          "0 0 0px 0px rgba(255,0,0,0)",
                          "0 0 20px 10px rgba(255,0,0,0.4)",
                          "0 0 0px 0px rgba(255,0,0,0)",
                        ],
                      }}
                      transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                    />
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-10 left-0 right-0 flex justify-center"
          style={{
            opacity: useTransform(scrollYProgress, [0, 0.2], [1, 0]),
          }}
        >
          <motion.div
            animate={{
              y: [0, 10, 0],
            }}
            transition={{
              duration: 2,
              ease: "easeInOut",
              repeat: Number.POSITIVE_INFINITY,
            }}
            className="flex flex-col items-center"
          >
            <p className="text-gray-400 mb-2 text-sm">SCROLL TO WITNESS</p>
            <div className="w-6 h-10 rounded-full border-2 border-gray-400 flex justify-center p-1">
              <motion.div
                animate={{
                  y: [0, 12, 0],
                }}
                transition={{
                  duration: 1.5,
                  ease: "easeInOut",
                  repeat: Number.POSITIVE_INFINITY,
                }}
                className="w-2 h-2 bg-red-500 rounded-full"
              />
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

export default TitanRevealSection
